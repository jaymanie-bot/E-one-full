import { injectionAncillaries } from "./ancillary-data";

export type Specification = { label: string; value: string };

export type Machine = {
  slug: string;
  title: string;
  category: MachineCategory;
  summary: string;
  overview: string[];
  features: string[];
  specs?: Specification[];
  specSource?: string;
  image: string;
};

export type MachineCategory =
  | "Auxiliary machines"
  | "Bottle blowing"
  | "Coding machines"
  | "Injection machines"
  | "Labelling machines"
  | "Liquid filling"
  | "Packaging machines"
  | "Water treatment";

export type Solution = {
  slug: string;
  title: string;
  image: string;
  summary: string;
  overview: string[];
  stages: { title: string; body: string }[];
  performanceNote?: string;
  relatedMachines: string[];
  specs?: Specification[];
  liquids?: { title: string; body: string }[];
  subsolutions?: string[];
};

const image = (slug: string) => `/catalogue/${slug}.webp`;

export const machines: Machine[] = [
  {
    slug: "oop-labelling-machine",
    title: "OPP Labelling Machine",
    category: "Labelling machines",
    summary: "A high-speed rotary system for applying hot-melt adhesive OPP labels in continuous production.",
    overview: [
      "The machine coordinates container infeed, label cutting, adhesive application and finished-container discharge in one continuous process.",
      "Glue is applied only at the label edges, which supports a neat overlap seal while limiting adhesive consumption.",
    ],
    features: [
      "Continuous rotary operation for high-throughput lines",
      "Automatic adjustment of incoming and outgoing containers",
      "Servo-driven label cutting for accurate placement",
      "Edge-only adhesive application to reduce glue usage",
      "Tight, smooth wrapping with controlled overlap sealing",
    ],
    image: image("oop-labelling-machine"),
  },
  {
    slug: "shrink-packaging-machine",
    title: "Shrink Packaging Machine",
    category: "Packaging machines",
    summary: "An automated end-of-line system for arranging bottles, wrapping film, shrinking and cooling finished bundles.",
    overview: [
      "The system handles bottle grouping and film application before the pack enters an adjustable heat-shrink section and cooling stage.",
      "Its compact layout is designed to reduce manual handling and create stable multipacks for retail or distribution.",
    ],
    features: [
      "Automated bottle sorting, film wrapping and shrinking",
      "Servo-controlled film feeding, coating and cutting",
      "Adjustable airflow and outlet position in the shrink tunnel",
      "Touchscreen controls for production settings",
      "Compact arrangement with accessible service points",
      "Source material reports 30% lower power use than the preceding model",
      "Industrial electrical detection components for stable operation",
    ],
    image: image("shrink-packaging-machine"),
  },
  {
    slug: "laser-coding-machine",
    title: "Laser Coding Machine",
    category: "Coding machines",
    summary: "A non-contact system for permanent production codes on PET, glass, aluminium cans and cartons.",
    overview: [
      "The laser marks batch details, expiry dates, barcodes and QR codes directly onto the packaging surface.",
      "Because the process does not use ink or solvent, it suits fast production lines that need durable, tamper-resistant identification.",
    ],
    features: [
      "Permanent, legible production marks",
      "Suitable for batch codes, dates, barcodes and QR codes",
      "Resistant to smudging, fading and routine environmental exposure",
      "Non-contact marking at production-line speed",
      "No ink or solvent consumables",
    ],
    image: image("laser-coding-machine"),
  },
  {
    slug: "inkjet-coding-machine",
    title: "Inkjet Coding Machine",
    category: "Coding machines",
    summary: "A high-speed, non-contact ink system for applying traceability information to beverage packaging.",
    overview: [
      "The system prints batch numbers, expiry dates, barcodes and logos while packaging continues along the line.",
      "Automatic monitoring, quick setup and a simplified service arrangement are intended to limit interruptions during production.",
    ],
    features: [
      "High-quality ink output at line speed",
      "Automatic operating-status monitoring",
      "Quick setup for shorter changeovers",
      "Menu-led operation for production teams",
      "Single-part servicing approach",
      "Solvent-saving system designed to reduce consumption and waste",
    ],
    image: image("inkjet-coding-machine"),
  },
  {
    slug: "cap-compression-machine",
    title: "Cap Compression Machine",
    category: "Injection machines",
    summary: "A rotary compression-moulding system for continuous, high-volume production of plastic closures.",
    overview: [
      "Raw material is dosed automatically before servo-controlled compression heads form caps under consistent pressure and temperature.",
      "The process is designed to produce repeatable cap weight and shape while limiting scrap and changeover time.",
    ],
    features: [
      "Continuous rotary cap production",
      "Automatic raw-material dosing and feeding",
      "Servo-controlled compression heads",
      "Reduced scrap through compression moulding",
      "Controlled temperature and pressure for uniform caps",
      "Support for multiple cap sizes, shapes and colours",
      "Short heating cycles and efficient cooling",
    ],
    image: image("cap-compression-machine"),
  },
  {
    slug: "automatic-rotary-bottle-blowing-machine",
    title: "Automatic Rotary Bottle Blowing Machine",
    category: "Bottle blowing",
    summary: "A high-output rotary blow-moulding platform for producing plastic bottles in multiple formats.",
    overview: [
      "The machine handles preforms continuously through the heating and blowing process, supporting stable large-scale bottle production.",
      "It is presented for food and beverage, cosmetics, pharmaceutical and chemical packaging applications.",
    ],
    features: [
      "Continuous rotary preform movement",
      "Configurable for different bottle shapes and sizes",
      "Designed for stable, energy-conscious production",
      "Supports PET, PE, PVC and PP formats where configured",
    ],
    specs: [{ label: "Stated output range", value: "8,000–36,000 bottles per hour, model dependent" }],
    image: image("automatic-rotary-bottle-blowing-machine"),
  },
  {
    slug: "automatic-linear-bottle-blowing-machine",
    title: "Automatic Linear Bottle Blowing Machine",
    category: "Bottle blowing",
    summary: "A linear blow-moulding machine for medium-speed production of plastic bottles in varied shapes and sizes.",
    overview: [
      "The platform uses a rigid single-plate steel frame to support repeatable forming and long-term machine stability.",
      "Its pressure-recovery arrangement reuses part of the high-pressure gas and reduces reliance on a separate low-pressure air system.",
    ],
    features: [
      "Medium-speed linear bottle production",
      "Single-piece steel frame for rigidity and precision",
      "High-pressure gas recovery to reduce operating demand",
      "Supports PET, PE, PVC and PP formats where configured",
    ],
    specs: [
      { label: "Stated output range", value: "3,000–8,000 bottles per hour, model dependent" },
      { label: "Gas recovery", value: "Up to 25% of high-pressure gas" },
    ],
    image: image("automatic-linear-bottle-blowing-machine"),
  },
  {
    slug: "glass-bottle-filling-machine",
    title: "Glass Bottle Filling Machine",
    category: "Liquid filling",
    summary: "A stainless-steel BXGF filling platform for filling, capping and sealing beverages in glass bottles.",
    overview: [
      "The system is designed around hygienic product handling, consistent filling and reduced waste on glass-bottle lines.",
      "Bottle separation and variable-speed control support a controlled flow through the machine.",
    ],
    features: [
      "Stainless-steel construction",
      "Screw-based bottle separation",
      "Frequency control with digital display",
      "Hygienic internal geometry designed to avoid debris-trapping edges",
      "Integrated filling, capping and sealing workflow",
    ],
    image: image("glass-bottle-filling-machine"),
  },
  {
    slug: "carbonated-filling-machine",
    title: "Carbonated Filling Machine",
    category: "Liquid filling",
    summary: "A DXGF rinsing, filling and capping system for soft drinks, sparkling water, beer and other carbonated products.",
    overview: [
      "The machine combines the three core filling operations in one unit and controls bottle movement to protect fill accuracy and carbonation.",
      "Its drive and handling systems are designed for stable output with low operating noise.",
    ],
    features: [
      "Integrated washing, filling and capping",
      "Precise liquid control at high production speed",
      "Pneumatic bottle conveying and mouth clamping",
      "Oil-nylon gear drive for stable, lower-noise operation",
      "Serviceable layout for routine maintenance",
    ],
    image: image("carbonated-filling-machine"),
  },
  {
    slug: "barrel-filling-machine",
    title: "Barrel Filling Machine",
    category: "Liquid filling",
    summary: "A QGF-series system for washing, filling, capping and sealing large water containers and drums.",
    overview: [
      "The line is designed for high-volume container handling with controlled dosing, low-drip nozzles and a hygienic product path.",
      "An integrated weighing option and adjustable filling speed support accurate operation across compatible container formats.",
    ],
    features: [
      "Automated filling sequence",
      "High-accuracy dosing",
      "Large-container compatibility",
      "Hygienic, durable construction",
      "Adjustable filling speed",
      "Leak-resistant, non-drip nozzles",
      "Operator-oriented controls",
      "Integrated weighing option",
      "Automatic capping and sealing",
    ],
    specs: [{ label: "Primary format", value: "19-litre water barrels, with other drums subject to configuration" }],
    image: image("barrel-filling-machine"),
  },
  {
    slug: "bottle-water-filling-machine",
    title: "Bottle Water Filling Machine",
    category: "Liquid filling",
    summary: "A CXGF-series automated system combining bottle rinsing, water filling and capping.",
    overview: [
      "The machine brings the principal bottling steps into a single controlled platform for hygienic, consistent drinking-water production.",
      "PLC control, bottle-mouth handling and automatic liquid-level management support reliable operation at production speed.",
    ],
    features: [
      "Integrated rinsing, filling and capping",
      "High-speed filling with stable liquid control",
      "Pneumatic conveying and bottle-mouth clamping",
      "Low-noise operation",
      "Oil-nylon gear drive",
      "PLC and touchscreen interface",
      "Automatic liquid-level control",
      "Machine safety controls for operators and production",
    ],
    image: image("bottle-water-filling-machine"),
  },
  {
    slug: "juice-filling-machine-hot-filling",
    title: "Juice Filling Machine (Hot Filling)",
    category: "Liquid filling",
    summary: "A configurable filling platform for hygienic hot filling of juice and juice-based beverages.",
    overview: [
      "The machine is intended for integration after juice preparation and thermal treatment, carrying heated product into compatible containers under controlled conditions.",
      "Final configuration is selected around the product, container, target output and the surrounding capping and packaging equipment.",
    ],
    features: [
      "Hot-fill process compatibility",
      "Flexible line configuration",
      "Integration with capping, coding and packaging equipment",
      "Built for dependable commercial production",
      "Project-specific output and container handling",
    ],
    image: image("juice-filling-machine-hot-filling"),
  },
  {
    slug: "sleeve-labelling",
    title: "Sleeve Labelling Machine",
    category: "Labelling machines",
    summary: "An automatic machine for placing shrinkable sleeves on bottles, jars, cans and other containers.",
    overview: [
      "Labels are cut and positioned around each container before a steam or hot-air stage shrinks the sleeve into place.",
      "The format is suited to full-body decoration, tamper bands and containers that need a close-fitting label.",
    ],
    features: [
      "Continuous high-speed labelling",
      "Compatibility with multiple container shapes and sizes",
      "Accurate high-speed sleeve cutting",
      "Automatic label placement",
      "Steam or hot-air shrinking for a secure finish",
    ],
    image: image("sleeve-labelling"),
  },
  {
    slug: "reverse-osmosis-ro-water-treatment-system",
    title: "Reverse Osmosis Water Treatment System",
    category: "Water treatment",
    summary: "A configurable RO platform for removing dissolved salts, minerals and remaining impurities after pretreatment.",
    overview: [
      "Pretreated water passes through precision filtration and RO membranes, separating purified product water from the concentrated reject stream.",
      "The system can be sized for commercial or industrial water-treatment requirements and integrated upstream of beverage filling.",
    ],
    features: [
      "High-efficiency membrane separation",
      "Removal of dissolved solids after pretreatment",
      "High water-recovery design",
      "Corrosion-resistant stainless-steel frame",
      "Capacity selected to the production requirement",
    ],
    specs: [{ label: "Available capacity", value: "1–50 tonnes per hour" }],
    image: image("reverse-osmosis-ro-water-treatment-system"),
  },
  {
    slug: "injection-moulding-machine",
    title: "Injection Moulding Machine",
    category: "Injection machines",
    summary: "A flexible plastic injection platform for repeatable, high-volume production across multiple industries.",
    overview: [
      "Configurable material and mould settings support varied component designs and faster changeovers between production requirements.",
      "An advanced servo motor and optimized hydraulic system are used to reduce energy demand while maintaining moulding performance.",
    ],
    features: [
      "Broad material and product-format flexibility",
      "Quick mould-change support",
      "Servo-driven control",
      "Optimized hydraulic system",
      "Suitable for medical, packaging and consumer-goods applications",
    ],
    image: image("injection-moulding-machine"),
  },
  {
    slug: "bottle-unscrambler",
    title: "Bottle Unscrambler",
    category: "Auxiliary machines",
    summary: "An automatic infeed machine that takes randomly loaded empty bottles and presents them upright to the line.",
    overview: [
      "Bulk plastic bottles enter from bins or crates before the machine separates, orients and sequences them.",
      "The upright bottles are transferred onto the conveyor ready for rinsing or filling.",
    ],
    features: [
      "Receives bulk empty bottles",
      "Separates tangled or mixed bottles",
      "Automatically orients bottles upright",
      "Feeds bottles sequentially to the conveyor",
      "Designed for integration into PET filling lines",
    ],
    image: image("bottle-unscrambler"),
  },
  {
    slug: "cxj-series-surf-fruit-cleaner",
    title: "CXJ Series Surf Fruit Cleaner",
    category: "Auxiliary machines",
    summary: "A fruit-washing system that uses water movement and bubbles to remove surface dirt and residues gently.",
    overview: [
      "The cleaner prepares fruit for downstream juice processing while limiting harsh mechanical handling.",
      "It can be integrated ahead of extraction and pulping equipment in a beverage preparation line.",
    ],
    features: [
      "Bubble-assisted surface washing",
      "Gentle handling for fruit processing",
      "Removal of loose dirt and surface residues",
      "Designed for integration with juice-preparation equipment",
    ],
    image: image("cxj-series-surf-fruit-cleaner"),
  },
  {
    slug: "dj-series-beater",
    title: "DJ Series Beater",
    category: "Auxiliary machines",
    summary: "A preparation machine for breaking down fruit and pulp into a smoother, more consistent process feed.",
    overview: [
      "The beater refines incoming fruit material before later extraction, homogenization or blending stages.",
      "It is positioned as part of a juice and beverage preparation system selected around the raw material and desired texture.",
    ],
    features: [
      "Fruit and pulp breakdown",
      "More uniform process texture",
      "Integration before extraction or blending",
      "Configuration matched to the raw ingredient",
    ],
    image: image("dj-series-beater"),
  },
  {
    slug: "gjb-series-high-compressor-homogenize",
    title: "GJB Series High-Pressure Homogenizer",
    category: "Auxiliary machines",
    summary: "A high-pressure processing system for distributing particles evenly and stabilizing liquid products.",
    overview: [
      "Homogenization helps create consistent texture and reduces separation before the beverage reaches filling.",
      "The machine can be integrated into beverage preparation lines where product stability and repeatable mouthfeel are required.",
    ],
    features: [
      "High-pressure homogenization",
      "Uniform particle distribution",
      "Improved liquid stability and consistency",
      "Integration with beverage preparation and filling lines",
    ],
    image: image("gjb-series-high-compressor-homogenize"),
  },
  {
    slug: "ly-series-cold-drink-tank",
    title: "LY Series Cold Drink Tank",
    category: "Auxiliary machines",
    summary: "A chilled holding and supply tank for maintaining beverage temperature and pressure before filling.",
    overview: [
      "The tank stores prepared cold or carbonated drink and supplies it to the filling machine under controlled conditions.",
      "Maintaining the appropriate temperature and pressure supports carbonation stability during high-speed filling.",
    ],
    features: [
      "Chilled beverage holding",
      "Controlled supply to the filling machine",
      "Temperature management before filling",
      "Pressure conditions suited to carbonated products",
    ],
    image: image("ly-series-cold-drink-tank"),
  },
  {
    slug: "lz-1-5-type-spiral-juice-extractor",
    title: "LZ-1.5 Spiral Juice Extractor",
    category: "Auxiliary machines",
    summary: "A spiral extraction machine for separating juice from fruit while leaving pulp and seeds behind.",
    overview: [
      "The extractor presses prepared produce to maximize liquid recovery and produce a smoother process stream.",
      "It can handle a range of soft fruit and harder produce when configured for the application.",
    ],
    features: [
      "High-yield juice extraction",
      "Pulp and seed separation",
      "Low-oxidation processing intended to protect product quality",
      "Support for soft fruit and firmer produce",
    ],
    image: image("lz-1-5-type-spiral-juice-extractor"),
  },
  {
    slug: "plate-sterilizing-equipment",
    title: "Plate Sterilizing Equipment",
    category: "Auxiliary machines",
    summary: "A thermal-treatment system for hygienic beverage processing and microbial control before filling.",
    overview: [
      "Plate equipment transfers heat efficiently to the product or cleaning medium as part of a controlled sterilization process.",
      "It supports hygienic treatment of beverage streams and product-contact circuits before the filling stage.",
    ],
    features: [
      "Controlled heat treatment",
      "Supports microbial-risk reduction",
      "Suitable for beverage process integration",
      "Works with steam or hot-water systems where configured",
    ],
    image: image("plate-sterilizing-equipment"),
  },
  {
    slug: "qhs-drink-mixer",
    title: "QHS Drink Mixer",
    category: "Auxiliary machines",
    summary: "A beverage-processing system for accurately combining water, syrup and CO₂ before carbonated filling.",
    overview: [
      "The mixer combines and stabilizes recipe components so flavour, sweetness and carbonation remain consistent throughout a production run.",
      "It is designed for direct integration with carbonated-drink filling equipment.",
    ],
    features: [
      "Controlled water and syrup proportioning",
      "CO₂ integration",
      "Consistent recipe mixing",
      "Product stabilization before filling",
      "Integration with high-speed carbonated lines",
    ],
    image: image("qhs-drink-mixer"),
  },
  {
    slug: "dth-series-electrothermal-sugar-melting-boiler",
    title: "DTH Electrothermal Sugar Melting Boiler",
    category: "Auxiliary machines",
    summary: "An electrically heated vessel for dissolving sugar and maintaining a uniform syrup for beverage production.",
    overview: [
      "Controlled electric heating and mixing dissolve sugar quickly while maintaining the selected syrup temperature.",
      "The process is intended to avoid localized caramelization, stabilize viscosity and supply a consistent feed to downstream blending.",
    ],
    features: [
      "Electric process heating",
      "Controlled syrup temperature",
      "Homogeneous sugar dissolution",
      "Mixing designed to limit caramelization",
      "Integration with beverage blending systems",
    ],
    image: image("dth-series-electrothermal-sugar-melting-boiler"),
  },
  {
    slug: "tq-2-vacuum-deaerator",
    title: "TQ-2 Vacuum Deaerator",
    category: "Auxiliary machines",
    summary: "A vacuum-processing unit for removing dissolved oxygen and other gases from liquid before carbonation and filling.",
    overview: [
      "Removing oxygen limits oxidation that can affect flavour and shelf life, while reducing gas interference during CO₂ dosing.",
      "Lower entrained-gas levels also help manage foam during filling and pressure imbalance in sealed packages.",
    ],
    features: [
      "Dissolved-oxygen removal",
      "Improved CO₂ dissolution efficiency",
      "Foam reduction during filling",
      "Support for package-pressure stability",
    ],
    image: image("tq-2-vacuum-deaerator"),
  },
  {
    slug: "djm-vertical-colloid-mill",
    title: "DJM Vertical Colloid Mill",
    category: "Auxiliary machines",
    summary: "A high-shear mill for reducing particle size and producing stable emulsions, suspensions and fine pastes.",
    overview: [
      "The mill homogenizes syrups, concentrates and flavour ingredients before carbonation or filling.",
      "It can refine fruit pulp and insoluble particles while helping stabilize oil-based flavours in beverage recipes.",
    ],
    features: [
      "High-shear particle-size reduction",
      "Syrup and concentrate homogenization",
      "Fine processing of fruit pulp and fibres",
      "Stabilization of emulsions and suspensions",
      "Food, beverage and pharmaceutical applications",
    ],
    image: image("djm-vertical-colloid-mill"),
  },
  ...injectionAncillaries,
];

export const solutions: Solution[] = [
  {
    slug: "bottled-water-production-line",
    title: "Turnkey Bottled Water Production",
    image: "/eone/bottled-water-line.webp",
    summary: "A complete PET water line covering bottle formation, purification, filling, labelling, coding and final packaging.",
    overview: [
      "Preforms are heated and stretch-blown on site, giving producers control over bottle design while reducing the storage and transport burden associated with empty bottles. An air conveyor moves the finished containers into the filling section.",
      "Raw water passes through configured filtration, reverse osmosis and UV or ozone treatment before entering the clean filling and capping environment.",
      "Filled bottles continue through the selected sleeve, sticker or OPP labelling system. Laser or inkjet coding adds the production date, batch and expiry details before shrink wrapping, tray packing or carton boxing.",
      "The modular layout supports capacity growth, access for maintenance and integration with plant utilities and end-of-line logistics.",
    ],
    stages: [
      { title: "Form the bottle", body: "Heat and stretch-blow PET preforms, then transfer the containers on a clean air conveyor." },
      { title: "Treat the water", body: "Configure filtration, reverse osmosis and disinfection around the source-water analysis." },
      { title: "Fill and close", body: "Rinse, fill and cap in a controlled system designed around the bottle and output target." },
      { title: "Label and pack", body: "Apply labels and traceability codes before wrapping, cartoning or pallet preparation." },
    ],
    specs: [
      { label: "Pack format", value: "PET bottles with a matched cap and neck finish" },
      { label: "Water treatment", value: "Filtration, RO and UV or ozone based on feed-water analysis" },
      { label: "Reference bottle-blower output", value: "Linear 3,000–8,000 BPH · rotary 8,000–36,000 BPH, by model" },
      { label: "Finished line capacity", value: "Quoted in bottles/hour for each bottle size, based on the filler and downstream equipment" },
    ],
    liquids: [
      { title: "Still drinking and purified water", body: "The standard application. Treatment and sanitation are selected around the incoming water quality and finished product." },
      { title: "Still mineral or flavoured water", body: "Mineral water requires a treatment design matched to its source and product requirements. Flavoured water may need blending and a different hygienic filling configuration." },
      { title: "Sparkling water or juice", body: "Sparkling water needs a pressure filler. Juice may require thermal processing and a hot-fill or aseptic system, depending on shelf life." },
    ],
    relatedMachines: ["automatic-rotary-bottle-blowing-machine", "automatic-linear-bottle-blowing-machine", "reverse-osmosis-ro-water-treatment-system", "bottle-water-filling-machine", "oop-labelling-machine", "sleeve-labelling", "laser-coding-machine", "inkjet-coding-machine", "shrink-packaging-machine"],
  },
  {
    slug: "carbonated-drink-production-line",
    title: "Turnkey Carbonated Drink Production",
    image: "/eone/carbonated-drink-line.webp",
    summary: "An integrated line for carbonated drinks in PET, glass or cans, from water preparation and mixing to filling and packaging.",
    overview: [
      "PET formats can begin with in-house bottle blowing, while glass bottles and cans enter through their dedicated handling and filling equipment.",
      "Treated water is chilled and combined with syrup and CO₂ under controlled temperature and pressure. Isobaric filling helps preserve carbonation and limit foaming.",
      "The configured closer or can seamer is followed by labelling, traceability coding and the selected retail or bulk packaging format.",
      "Automation and multi-format equipment allow the line to serve both mass-market drinks and premium sparkling products.",
    ],
    stages: [
      { title: "Prepare containers", body: "Blow PET bottles on site or feed the line with compatible glass bottles or cans." },
      { title: "Mix and carbonate", body: "Treat water, proportion syrup and dissolve CO₂ under controlled process conditions." },
      { title: "Fill under pressure", body: "Use isobaric filling to protect carbonation and achieve repeatable fill levels." },
      { title: "Close and pack", body: "Cap or seam, code and label each container before secondary packaging." },
    ],
    specs: [
      { label: "Pack formats", value: "PET, glass or cans with format-specific filling and closing equipment" },
      { label: "Process", value: "Water treatment, chilling, recipe blending, CO₂ dosing and isobaric filling" },
      { label: "Reference PET blower output", value: "8,000–36,000 bottles/hour for the listed rotary blower range" },
      { label: "Finished line capacity", value: "Quoted in bottles or cans/hour for the recipe, temperature, carbonation and pack size" },
    ],
    liquids: [
      { title: "Carbonated soft drinks", body: "Cola, citrus and other flavoured sodas can use a syrup-mixing and carbonation setup matched to the recipe." },
      { title: "Sparkling water and other fizzy drinks", body: "Unsweetened sparkling water, tonic and carbonated energy drinks can be evaluated against their ingredients, carbonation and package." },
      { title: "Beer or other foam-sensitive drinks", body: "Confirm the filler, oxygen-control requirements and cleaning process for the product before choosing the configuration." },
    ],
    relatedMachines: ["automatic-rotary-bottle-blowing-machine", "qhs-drink-mixer", "tq-2-vacuum-deaerator", "ly-series-cold-drink-tank", "carbonated-filling-machine", "glass-bottle-filling-machine", "oop-labelling-machine", "laser-coding-machine", "shrink-packaging-machine"],
  },
  {
    slug: "barrel-water-production-line",
    title: "Barrel Water Production Line",
    image: "/eone/barrel-water-line.webp",
    summary: "A hygienic line for returned or new 19-litre water barrels, integrating washing, filling, capping and coding.",
    overview: [
      "Returned bottles pass through external and multi-stage internal washing with hot water, detergent, disinfectant and high-pressure rinsing. New bottles can enter after the appropriate external rinse.",
      "Water is prepared through the selected filtration, reverse-osmosis and disinfection stages before accurate filling into large containers.",
      "The barrels are capped and marked with production, batch and expiry information for distribution to homes, offices and commercial users.",
      "Automated handling reduces dependence on manual operations and supports consistent sanitation, throughput and resource use.",
    ],
    stages: [
      { title: "Wash returned barrels", body: "Run internal and external cleaning stages matched to the returnable-container programme." },
      { title: "Purify the water", body: "Combine media filtration, reverse osmosis and UV or ozone treatment as required." },
      { title: "Fill and cap", body: "Dose purified water into 19-litre containers and apply the closure automatically." },
      { title: "Code for traceability", body: "Add production and batch information before dispatch." },
    ],
    relatedMachines: ["reverse-osmosis-ro-water-treatment-system", "barrel-filling-machine", "laser-coding-machine", "inkjet-coding-machine"],
  },
  {
    slug: "dairy-milk-production-line",
    title: "Dairy Milk Production Line",
    image: "/eone/dairy-milk-line.webp",
    summary: "A hygienic process line for fresh or long-life milk, from reception and standardization to filling and secondary packaging.",
    overview: [
      "Raw milk is received, tested, chilled, clarified and filtered. Standardization sets the required fat level, with separation or cream recovery added when the product needs it.",
      "Thermal processing can use HTST pasteurization for fresh milk or UHT treatment for shelf-stable formats. Homogenization then supports a smooth, stable product.",
      "The line can fill HDPE or PET bottles, glass, gable-top cartons or sachets in an ultra-clean or aseptic environment selected for the required shelf life.",
      "Coding and labelling provide traceability before shrink wrapping, crate packing or carton boxing for chilled or ambient distribution.",
    ],
    stages: [
      { title: "Receive and standardize", body: "Test, chill, clarify and adjust raw milk to the target product specification." },
      { title: "Heat-treat", body: "Choose HTST pasteurization or UHT processing around shelf-life requirements." },
      { title: "Homogenize and hold", body: "Create a stable texture and maintain hygienic conditions ahead of filling." },
      { title: "Fill and package", body: "Select the container, hygiene level, coding and secondary packaging for distribution." },
    ],
    performanceNote: "The source material cites potential reductions of up to 50% in water use and 30% in energy use through optimized CIP, heat recovery and modular design. Project engineering determines achievable results.",
    relatedMachines: ["plate-sterilizing-equipment", "gjb-series-high-compressor-homogenize", "glass-bottle-filling-machine", "laser-coding-machine", "inkjet-coding-machine", "shrink-packaging-machine"],
  },
  {
    slug: "juice-production-line",
    title: "Juice Production Line",
    image: "/eone/juice-line.webp",
    summary: "A modular line for fruit juices, nectars and juice drinks, covering preparation, thermal treatment, filling and packing.",
    overview: [
      "Production can begin with fresh-fruit cleaning and extraction or dilution of concentrate. Deaeration and standardization help maintain flavour and repeatable composition, while process water is filtered and disinfected.",
      "Pasteurization or UHT processing is selected for the required shelf life, with homogenization available to improve texture and stability. Sugar syrup, stabilizers and flavours can be dosed in the blending stage.",
      "The hygienic or aseptic filler can be configured for PET, glass, cartons or pouches. Labelling and coding add required product and traceability information.",
      "Shrink wrapping, tray packing or cartoning prepare the product for retail or bulk distribution, with palletizing available for warehouse-ready output.",
    ],
    stages: [
      { title: "Prepare the fruit", body: "Clean, break down and extract fresh produce, or prepare concentrate for blending." },
      { title: "Standardize and treat", body: "Deaerate, dose ingredients and apply pasteurization or UHT processing." },
      { title: "Fill hygienically", body: "Choose the hygiene level and filler around product, container and shelf life." },
      { title: "Identify and pack", body: "Label, code and pack the finished juice for its distribution format." },
    ],
    relatedMachines: ["cxj-series-surf-fruit-cleaner", "dj-series-beater", "lz-1-5-type-spiral-juice-extractor", "djm-vertical-colloid-mill", "tq-2-vacuum-deaerator", "plate-sterilizing-equipment", "juice-filling-machine-hot-filling", "sleeve-labelling", "laser-coding-machine", "shrink-packaging-machine"],
  },
  {
    slug: "plastic-injection-cap-compression-machines",
    title: "Total Injection Machines",
    image: "/eone/plastic-injection.webp",
    summary: "Plastic-processing systems for PET preforms, packaging components and high-volume closure production.",
    overview: [
      "The portfolio combines injection moulding for PET preforms and other components with compression moulding for beverage and packaging caps.",
      "Machine configuration is selected around material, mould, part geometry, cycle requirements and the required level of production flexibility.",
      "Applications extend across beverage, edible oil, personal care, household and industrial packaging.",
    ],
    stages: [
      { title: "Define the component", body: "Confirm resin, geometry, tolerances, colour and expected production volume." },
      { title: "Select the process", body: "Choose injection moulding for preforms and components or compression moulding for closures." },
      { title: "Engineer the mould", body: "Match the machine, mould and utilities to the component and cycle target." },
      { title: "Commission production", body: "Validate part quality, repeatability, handling and operator procedures." },
    ],
    relatedMachines: ["injection-moulding-machine", "cap-compression-machine"],
  },
  {
    slug: "edible-oil-filling-machines",
    title: "Edible Oil Filling Machines",
    image: "/eone/edible-oil-line.webp",
    summary: "Configurable filling and packaging systems for vegetable, palm, sunflower, soybean, groundnut and specialty oils.",
    overview: [
      "The filling system can be engineered for PET or glass bottles, HDPE jerry cans, pouches and metal tins across small retail and bulk formats.",
      "Semi-automatic arrangements use operator bottle placement for lower or moderate output. Fully automatic lines add conveyors, controlled nozzles and PLC/HMI operation for higher throughput.",
      "Labelling, coding and secondary packaging can be integrated around the selected container and route to market.",
    ],
    stages: [
      { title: "Define the oil and pack", body: "Confirm product viscosity, container material, size and closure." },
      { title: "Select automation", body: "Choose operator-assisted or fully automatic handling around the target output." },
      { title: "Fill accurately", body: "Configure the nozzle and dosing method for clean filling with controlled product loss." },
      { title: "Finish the pack", body: "Add capping, labelling, traceability coding and secondary packaging." },
    ],
    performanceNote: "The source range covers containers from 250 ml to 25 L and larger project-specific formats.",
    relatedMachines: ["oop-labelling-machine", "sleeve-labelling", "laser-coding-machine", "inkjet-coding-machine", "shrink-packaging-machine"],
  },
  {
    slug: "moulds",
    title: "Moulds",
    image: "/eone/hero-moulds.webp",
    summary: "Precision moulds specified around your product drawing, resin, machine and target cycle.",
    overview: [
      "E-One works with its mould technology partner to scope tooling for PET preforms, closures and custom plastic components. Start with a drawing or sample, material grade, expected volume and the proposed production machine.",
      "A mould design review covers cavity balance, cooling, ejection and maintenance access. For preforms and caps, verify the neck finish and mating dimensions so the tooling fits the bottle and closure system.",
      "Agree on sample approval and acceptance criteria up front. Trial parts let the team check critical dimensions, weight and finish against the drawing before releasing the tool to production.",
    ],
    stages: [
      { title: "PET preform moulds", body: "Match preform weight, neck finish and cavity count to the injection press and downstream bottle design." },
      { title: "Closure moulds", body: "Specify thread, sealing geometry and any tamper-evident features around the intended bottle neck." },
      { title: "Custom component moulds", body: "Review wall thickness, surface finish, tolerances, parting lines and ejection for the target component." },
      { title: "Bottle blowing moulds", body: "Match the mould to the bottle drawing, cavity layout and linear or rotary blow-moulding machine." },
    ],
    specs: [
      { label: "Cavities and runner", value: "Cavity count and hot- or cold-runner layout selected for the part and output target" },
      { label: "Tool steel and finish", value: "Agreed against the resin, expected tool life and surface requirements" },
      { label: "Machine compatibility", value: "Platen and tie-bar clearance, shut height, shot capacity and ejection interface" },
      { label: "Acceptance criteria", value: "Sample dimensions, part weight, appearance, repeatability and target cycle time" },
    ],
    relatedMachines: ["injection-moulding-machine", "cap-compression-machine"],
  },
  {
    slug: "turnkey-beverage",
    title: "Turnkey Beverage Solutions",
    image: "/eone/bottled-water-line.webp",
    summary: "Complete bottled-water and carbonated-drink lines, from processing and filling to coding and final packaging.",
    overview: [
      "E-One scopes each production line around the beverage recipe, packaging format and finished units per hour. The line design brings together the process equipment, container handling, filling and downstream systems.",
      "Choose a line below to see its equipment, capacity considerations and the liquids that can be evaluated for the same production setup.",
    ],
    stages: [],
    subsolutions: ["bottled-water-production-line", "carbonated-drink-production-line"],
    relatedMachines: [],
  },
];

export const majorSolutions = [
  "plastic-injection-cap-compression-machines",
  "moulds",
  "turnkey-beverage",
];

export const machineCategoryLabels: Record<"All machines" | MachineCategory, string> = {
  "All machines": "All Machines",
  "Auxiliary machines": "Ancillary Machines",
  "Bottle blowing": "Bottle Blowing Machine",
  "Coding machines": "Coding Machines",
  "Injection machines": "Injection Machines",
  "Labelling machines": "Labelling Machines",
  "Liquid filling": "Liquid Filling Machine",
  "Packaging machines": "Packaging Machines",
  "Water treatment": "Water Treatment",
};

export const machineSizingDetails: Record<MachineCategory, Specification> = {
  "Auxiliary machines": { label: "Process capacity", value: "Select the model using product or material type, hourly throughput and the connection to the next stage." },
  "Bottle blowing": { label: "Bottle and tooling format", value: "Confirm preform weight, neck finish, bottle volume, mould cavities and compressed-air capacity." },
  "Coding machines": { label: "Print configuration", value: "Confirm packaging material, line speed, code dimensions and the required mark or ink system." },
  "Injection machines": { label: "Mould and capacity", value: "Confirm resin, part weight, cavity count, mould dimensions, target cycle and required output per hour." },
  "Labelling machines": { label: "Label and bottle format", value: "Confirm label material and dimensions, bottle shape and diameter, and required bottles per hour." },
  "Liquid filling": { label: "Filling capacity", value: "Confirm product, fill volume, temperature, container and closure. Throughput is quoted for that combination." },
  "Packaging machines": { label: "Pack and output", value: "Confirm container dimensions, pack pattern, packaging material and required packs per minute." },
  "Water treatment": { label: "System sizing", value: "Confirm source-water analysis, required treated-water flow, recovery target and disinfection requirements." },
};

export const machineCategories: ("All machines" | MachineCategory)[] = [
  "All machines",
  "Auxiliary machines",
  "Bottle blowing",
  "Coding machines",
  "Injection machines",
  "Labelling machines",
  "Liquid filling",
  "Packaging machines",
  "Water treatment",
];

export const machineBySlug = (slug: string) => machines.find((machine) => machine.slug === slug);
export const solutionBySlug = (slug: string) => solutions.find((solution) => solution.slug === slug);

